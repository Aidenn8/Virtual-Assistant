package ktbyte.assistant;

public class Main {
    public static void main(String[] args) {
        Assistant.main(args);
    }
}












//Make sure to pick an API WITHOUT OAuth.
//https://github.com/public-apis/public-apis#anime
//https://icanhazdadjoke.com/api#calling-the-api
//https://uselessfacts.jsph.pl/
//https://uselessfacts.jsph.pl/random.json?language=en